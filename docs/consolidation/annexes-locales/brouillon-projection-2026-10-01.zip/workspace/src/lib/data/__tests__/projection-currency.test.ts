import { beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ rpc: vi.fn() }));
vi.mock("@/lib/data/supabase-client", () => ({
  DOCUMENTS_BUCKET: "documents",
  ownerId: () => "owner",
  supabaseAdmin: () => mocks,
}));
import { createSupabaseRepository, validateSimulationRun } from "@/lib/data/supabase-repository";
import { createScenarioVersion } from "@/lib/engine/scenario-engine";
import type { SimulationRun } from "@/lib/data/contracts";
const definition = createScenarioVersion({
  scenarioId: "11111111-1111-4111-8111-111111111111",
  asOfDate: "2026-09-23",
  horizonMonths: 12,
  createdAt: "2026-09-23T00:00:00Z",
});
function run(currency: string | null | undefined): SimulationRun {
  return {
    scenarioId: definition.scenarioId,
    seed: 7,
    simulations: 100,
    years: 1,
    methodology: "fixture",
    points: [{ year: 2027, p10: 0, p25: 100, p50: 200, p75: 300, p90: 400 }],
    scenarioVersion: 1,
    asOfDate: definition.asOfDate,
    baselineReference: {
      reportingCurrency: currency,
      kind: "CANONICAL_AS_OF",
      asOfDate: definition.asOfDate,
      openingFingerprint: "fixture",
      eventSetVersion: "fixture",
      eventIds: [],
    },
    eventSetVersion: "fixture",
    assumptionsSnapshot: [],
    runMode: "MONTE_CARLO",
    horizonMonths: 12,
    methodologyVersion: definition.methodologyVersion,
    definitionSnapshot: definition,
  };
}
beforeEach(() => {
  vi.resetAllMocks();
  mocks.rpc.mockResolvedValue({ data: "run", error: null });
});
describe("Projection : devise persistée dans la référence de contexte JSONB", () => {
  it("transmet la devise à la RPC existante, sans toucher aux points", async () => {
    const input = run("USD");
    expect(await createSupabaseRepository("owner").saveSimulation(input)).toBe("run");
    expect(mocks.rpc).toHaveBeenCalledWith(
      "lfo_save_simulation_v2",
      expect.objectContaining({
        p_user_id: "owner",
        p_baseline_reference: input.baselineReference,
        p_points: input.points,
      }),
    );
    expect(
      JSON.parse(JSON.stringify(mocks.rpc.mock.calls[0][1])).p_baseline_reference.reportingCurrency,
    ).toBe("USD");
  });
  it.each([null, undefined])("ne réécrit pas une ancienne absence (%s)", (currency) => {
    expect(() => validateSimulationRun(run(currency))).not.toThrow();
  });
  it.each(["usd", "", "US"])("refuse %s avant RPC", async (currency) => {
    await expect(createSupabaseRepository("owner").saveSimulation(run(currency))).rejects.toThrow(
      "devise de projection invalide",
    );
    expect(mocks.rpc).not.toHaveBeenCalled();
  });
});
