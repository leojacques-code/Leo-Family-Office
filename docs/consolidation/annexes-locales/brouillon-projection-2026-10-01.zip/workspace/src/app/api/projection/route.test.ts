import { beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({
  auth: vi.fn(),
  read: vi.fn(),
  save: vi.fn(),
  global: vi.fn(),
  v2: vi.fn(),
  legacy: vi.fn(),
  opening: vi.fn(),
  deterministic: vi.fn(),
  assumptions: vi.fn(),
  annual: vi.fn(),
}));
vi.mock("@/lib/auth", () => ({ requireAuthenticated: mocks.auth }));
vi.mock("@/lib/data/repository", () => ({
  getRepository: async () => ({ getDashboardState: mocks.read, saveSimulation: mocks.save }),
}));
vi.mock("@/lib/engine/global-financial-model", () => ({ evaluateGlobalScenario: mocks.global }));
vi.mock("@/lib/engine/monte-carlo", () => ({
  runScenarioMonteCarlo: mocks.v2,
  runMonteCarlo: mocks.legacy,
}));
vi.mock("@/lib/engine/monthly-financial-model", () => ({
  buildOpeningBalanceSheet: mocks.opening,
  runDeterministicModel: mocks.deterministic,
  scenarioAssumptions: mocks.assumptions,
  toAnnualPoints: mocks.annual,
}));
import { POST } from "./route";
const post = (body: unknown = { scenarioId: "scenario", simulations: 100, seed: 7 }) =>
  POST(
    new Request("http://localhost/api/projection", { method: "POST", body: JSON.stringify(body) }),
  );
beforeEach(() => {
  vi.resetAllMocks();
  mocks.auth.mockResolvedValue(undefined);
  mocks.save.mockResolvedValue("run");
  mocks.read.mockResolvedValue({
    reportingCurrency: "USD",
    scenarios: [
      {
        id: "scenario",
        definition: {
          version: 2,
          horizonMonths: 12,
          asOfDate: "2026-09-23",
          assumptions: [],
          capitalAllocation: { investmentAllocationRate: 0 },
          market: { annualReturn: 0 },
          methodologyVersion: "fixture",
        },
      },
    ],
  });
  mocks.global.mockReturnValue({
    context: { reportingCurrency: "CHF", opening: { netWorth: 800 }, timeline: { events: [] } },
    baseline: { eventSetVersion: "events" },
    comparison: { completeness: "READY", scenario: { annual: [] } },
  });
  const result = {
    scenarioId: "scenario",
    seed: 7,
    simulations: 100,
    points: [{ year: 2027, p10: 0, p25: 100, p50: 200, p75: 300, p90: 400 }],
    methodology: "fixture",
  };
  mocks.v2.mockReturnValue(result);
  mocks.legacy.mockReturnValue(result);
  mocks.opening.mockReturnValue({ netWorth: 800 });
  mocks.assumptions.mockReturnValue({
    operatingSurplus: 0,
    investmentAllocationRate: 0,
    annualReturn: 0,
  });
  mocks.annual.mockReturnValue([]);
});
describe("Projection : devise du contexte transmis, moteurs intégralement simulés", () => {
  it("transmet la même unité au moteur V2, à la persistance et à la réponse", async () => {
    const response = await post();
    expect(response.status).toBe(200);
    expect(mocks.v2).toHaveBeenCalledWith(
      expect.objectContaining({ reportingCurrency: "CHF", seed: 7, simulations: 100 }),
    );
    expect(mocks.save).toHaveBeenCalledWith(
      expect.objectContaining({
        baselineReference: { eventSetVersion: "events", reportingCurrency: "CHF" },
      }),
    );
    expect(await response.json()).toMatchObject({
      reportingCurrency: "CHF",
      baselineReference: { reportingCurrency: "CHF" },
      openingNetWorth: 800,
      runId: "run",
    });
  });
  it("refuse le scénario historique hors EUR avant calcul ou écriture", async () => {
    mocks.read.mockResolvedValue({ reportingCurrency: "USD", scenarios: [{ id: "scenario" }] });
    const response = await post();
    expect(response.status).toBe(422);
    expect((await response.json()).error).toContain("historique");
    expect(mocks.legacy).not.toHaveBeenCalled();
    expect(mocks.opening).not.toHaveBeenCalled();
    expect(mocks.save).not.toHaveBeenCalled();
  });
  it("annonce EUR pour le parcours historique EUR existant", async () => {
    mocks.read.mockResolvedValue({ reportingCurrency: "EUR", scenarios: [{ id: "scenario" }] });
    const response = await post();
    expect(response.status).toBe(200);
    expect((await response.json()).reportingCurrency).toBe("EUR");
    expect(mocks.legacy).toHaveBeenCalledOnce();
  });
  it("ne sauvegarde pas un résultat V2 non calculable", async () => {
    mocks.global.mockReturnValue({ comparison: { completeness: "NOT_COMPUTABLE", blockers: [] } });
    expect((await post()).status).toBe(422);
    expect(mocks.v2).not.toHaveBeenCalled();
    expect(mocks.save).not.toHaveBeenCalled();
  });
  it("refuse la session absente avant toute lecture", async () => {
    mocks.auth.mockRejectedValue(new Error("UNAUTHORIZED"));
    expect((await post()).status).toBe(401);
    expect(mocks.read).not.toHaveBeenCalled();
  });
  it("refuse une requête invalide avant toute lecture", async () => {
    expect((await post({ scenarioId: "scenario", simulations: 1 })).status).toBe(400);
    expect(mocks.read).not.toHaveBeenCalled();
  });
});
