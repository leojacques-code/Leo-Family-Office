import { Currency } from "@/components/ui";
import type { ProjectionEnvelope } from "@/lib/types";

/** Les percentiles conservent l’unité de leur exécution, jamais celle du contexte courant. */
export function ProjectionPercentiles({ projection }: { projection: ProjectionEnvelope }) {
  const finalPoint = projection.points.at(-1);
  const currency = projection.reportingCurrency ?? null;
  return (
    <div>
      <p className="muted-copy">Devise de cette projection : {currency ?? "non renseignée"}</p>
      <div className="percentile-cards">
        {(
          [
            ["p10", "P10", "Patrimoine net dépassé dans ~90 % des simulations"],
            ["p50", "P50", "Patrimoine net médian des simulations"],
            ["p90", "P90", "Patrimoine net atteint ou dépassé dans ~10 % des simulations"],
          ] as const
        ).map(([key, label, detail]) => (
          <div key={key}>
            <span>{label}</span>
            <strong>
              <Currency value={finalPoint?.[key] ?? null} currency={currency} compact />
            </strong>
            <small>{detail}</small>
          </div>
        ))}
      </div>
    </div>
  );
}
