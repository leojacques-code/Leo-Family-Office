import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { ProjectionPercentiles } from "./projection-percentiles";
import type { ProjectionEnvelope } from "@/lib/types";
function projection(currency: string | null | undefined): ProjectionEnvelope {
  return {
    reportingCurrency: currency,
    scenarioId: "fixture",
    seed: 7,
    simulations: 100,
    methodology: "fixture sans calcul",
    points: [{ year: 2027, age: 24, p10: 0, p25: 100, p50: 200, p75: 300, p90: 400 }],
    deterministic: [],
    openingNetWorth: 150,
    assumptions: { operatingSurplusBeforeDebt: 0, investmentAllocationRate: 0, annualReturn: 0 },
  };
}
describe("Percentiles : unité propre de la réponse", () => {
  it.each(["USD", "CHF"])("affiche %s pour tous les percentiles, y compris zéro", (currency) => {
    const { container } = render(<ProjectionPercentiles projection={projection(currency)} />);
    expect(container).toHaveTextContent(`Devise de cette projection : ${currency}`);
    const symbol = currency === "USD" ? "$US" : "CHF";
    expect(container.querySelectorAll("strong")).toHaveLength(3);
    for (const amount of container.querySelectorAll("strong"))
      expect(amount).toHaveTextContent(symbol);
    expect(screen.getByText("P10").parentElement).toHaveTextContent(`0 ${symbol}`);
    expect(container).not.toHaveTextContent("€");
  });
  it.each([null, undefined])("garde l’unité absente explicite (%s)", (currency) => {
    const { container } = render(<ProjectionPercentiles projection={projection(currency)} />);
    expect(container).toHaveTextContent("0 (devise non renseignée)");
    expect(container).not.toHaveTextContent("€");
  });
  it("ne transforme pas une série absente en zéro", () => {
    const p = projection("USD");
    p.points = [];
    const { container } = render(<ProjectionPercentiles projection={p} />);
    for (const amount of container.querySelectorAll("strong"))
      expect(amount).toHaveTextContent("Non calculable");
  });
});
