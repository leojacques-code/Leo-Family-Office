/** Recette de métadonnées, réservée à une base locale jetable explicitement nommée. */
import pg from "pg";
const connectionString = process.env.LFO_LOCAL_DB_URL;
if (!connectionString) throw new Error("LFO_LOCAL_DB_URL requis");
const url = new URL(connectionString);
if (
  !["127.0.0.1", "localhost", "[::1]"].includes(url.hostname) ||
  !url.pathname.startsWith("/lfo_projection_currency_recipe_")
)
  throw new Error("Cette recette exige une base locale dédiée lfo_projection_currency_recipe_*");
const client = new pg.Client({ connectionString });
const owner = "00000000-0000-4000-8000-000000000001";
const date = "2026-09-23";
await client.connect();
try {
  if (process.argv[2] === "seed") {
    await client.query("begin");
    await client.query(
      `insert into public.profiles(user_id,display_name,reporting_currency,first_intent) values($1,'Recette projection USD','USD','PROJECT') on conflict(user_id) do update set display_name=excluded.display_name,reporting_currency=excluded.reporting_currency,first_intent=excluded.first_intent`,
      [owner],
    );
    await client.query("select public.lfo_add_account($1,$2,$3,$4,$5,$6,$7)", [
      owner,
      "Banque fictive",
      "Compte recette USD",
      "BANK",
      1200,
      "USD",
      date,
    ]);
    const definition = {
      schemaVersion: 2,
      methodologyVersion: "SCENARIOS_V2_EVENT_MONTHLY_1",
      scenarioId: "11111111-1111-4111-8111-111111111111",
      version: 1,
      asOfDate: date,
      horizonMonths: 12,
      lifecycleStatus: "DRAFT",
      overrides: [],
      assumptions: [],
      market: {
        annualReturn: 0,
        annualVolatility: 0,
        annualInflation: 0,
        stressProbability: 0,
        shockYear: null,
        shockMagnitude: null,
        randomVariables: ["PORTFOLIO_RETURN"],
      },
      capitalAllocation: { investmentAllocationRate: 0, source: "EXPLICIT" },
      createdAt: `${date}T00:00:00Z`,
      legacyCompatibility: null,
    };
    const result = await client.query(
      "select public.lfo_create_scenario_v2($1,$2,$3,$4,$5,$6) as id",
      [
        owner,
        "Projection USD recette",
        "Fixture locale jetable",
        "#39747a",
        definition,
        `${date}T00:00:00Z`,
      ],
    );
    await client.query("commit");
    console.log(JSON.stringify({ scenarioId: result.rows[0].id }));
  } else if (process.argv[2] === "read") {
    const result = await client.query(
      `select r.id,r.scenario_id,r.baseline_reference->>'reportingCurrency' as reporting_currency,r.seed,r.simulations,count(p.id)::integer as point_count from public.simulation_runs r left join public.simulation_results p on p.run_id=r.id where r.user_id=$1 group by r.id order by r.created_at`,
      [owner],
    );
    console.log(JSON.stringify(result.rows, null, 2));
  } else throw new Error("Mode requis : seed ou read");
} finally {
  await client.end();
}
