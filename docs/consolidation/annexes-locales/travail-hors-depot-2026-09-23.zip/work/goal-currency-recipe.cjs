const {Client}=require('./Leo-Family-Office/node_modules/pg');
const db=new Client({connectionString:'postgres://postgres@127.0.0.1:55439/lfo_goal_currency_20260923'});
const owner='00000000-0000-4000-8000-000000000001';
(async()=>{await db.connect();
if(process.argv[2]==='read') {console.log(JSON.stringify((await db.query(`select g.name,g.current_version,v.version,v.payload->'target' as target from public.goals g join public.goal_versions v on v.goal_id=g.id order by g.id,v.version`)).rows,null,2));}
else {
 await db.query(`insert into public.profiles(user_id,display_name,reporting_currency,first_intent) values($1,'Recette devises Objectifs','EUR','PROJECT') on conflict(user_id) do update set display_name=excluded.display_name,first_intent=excluded.first_intent`,[owner]);
 for(const [id,currency,name] of [['aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','USD','Projet USD recette']]) {
 const definition={schemaVersion:2,methodologyVersion:'GOALS_V2_CANONICAL_TRAJECTORY_1',purpose:'CAPITAL',goalId:id,version:1,name,description:null,status:'ACTIVE',priority:2,constraintStrength:'SOFT',target:{metric:'NET_WORTH',operator:'AT_LEAST',value:1200,currency,entityId:null},targetDate:'2030-09-23',targetWindow:null,createdAt:'2026-09-23T00:00:00Z',legacyCompatibility:false};
 await db.query('select public.lfo_create_goal_v2($1,$2,$3)',[owner,definition,'2026-09-23T00:00:00Z']);
 }
 console.log('Objectif USD de recette créé');
} await db.end();})().catch(async e=>{console.error(e.message);await db.end();process.exitCode=1});
