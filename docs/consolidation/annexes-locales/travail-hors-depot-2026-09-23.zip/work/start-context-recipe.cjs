const crypto=require('crypto'),{spawn}=require('child_process');
const encode=o=>Buffer.from(JSON.stringify(o)).toString('base64url');
const now=Math.floor(Date.now()/1000);
const unsigned=encode({alg:'HS256',typ:'JWT'})+'.'+encode({role:'service_role',iat:now-60,exp:now+28800});
const token=unsigned+'.'+crypto.createHmac('sha256','local-recipe-only-not-a-production-secret-20260911').update(unsigned).digest('base64url');
const child=spawn(process.execPath,['node_modules/next/dist/bin/next','dev','--hostname','127.0.0.1','--port','3110'],{stdio:'inherit',env:{...process.env,SUPABASE_URL:'http://127.0.0.1:55447',SUPABASE_SECRET_KEY:token,LFO_AUTH_MODE:'local-fixture',OWNER_USER_ID:'00000000-0000-4000-8000-000000000001'}});
child.on('exit',code=>process.exit(code??1));
