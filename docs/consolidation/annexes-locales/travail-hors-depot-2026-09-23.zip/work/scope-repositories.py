from pathlib import Path
import re
root=Path('.')
for stem,kind in [('supabase','Supabase'),('import','Import'),('fec','Fec'),('public-data','PublicData'),('portfolio-import','PortfolioImport')]:
 p=root/f'src/lib/data/{stem}-repository.ts';s=p.read_text();s=s.replace('ownerId, ','').replace('  ownerId,\n','');s=s.replace(f'function create{kind}Repository()',f'function create{kind}Repository(user: string)');s=s.replace('  const user = ownerId();\n','');
 if stem!='supabase':
  s='import { requireActor } from "@/lib/auth";\n'+s
  a=s.index(f'let cached: {kind}Repository | undefined;');b=s.index('\n}',a)+2
  s=s[:a]+f'''export async function get{kind}Repository(): Promise<{kind}Repository> {{
  const actor = await requireActor();
  return create{kind}Repository(actor.userId);
}}'''+s[b:]
 p.write_text(s)
for stem,kind,cls,field in [('document','Document','SupabaseDocumentRepository','user'),('registry','Registry','SupabaseRegistryRepository','user'),('open-banking','OpenBanking','OpenBankingRepository','userId')]:
 p=root/f'src/lib/data/{stem}-repository.ts';s=p.read_text().replace('ownerId, ','').replace('  ownerId,\n','');s='import { requireActor } from "@/lib/auth";\n'+s;s=s.replace(f'  private readonly {field} = ownerId();',f'  constructor(private readonly {field}: string) {{}}');a=s.index(f'let repository: {kind}Repository | undefined;');b=s.index('\n}',a)+2;s=s[:a]+f'''export async function get{kind}Repository(): Promise<{kind}Repository> {{
  const actor = await requireActor();
  return new {cls}(actor.userId);
}}'''+s[b:];p.write_text(s)
p=root/'src/lib/data/repository.ts';s=p.read_text();s=s.replace('import "server-only";', 'import "server-only";\nimport { requireActor } from "@/lib/auth";');a=s.index('let cached:');s=s[:a]+'''export async function getRepository(): Promise<FamilyOfficeRepository> {
  const actor = await requireActor();
  const { createSupabaseRepository } = await import("@/lib/data/supabase-repository");
  return createSupabaseRepository(actor.userId);
}
''';p.write_text(s)
p=root/'src/lib/data/supabase-client.ts';s=p.read_text();a=s.index('/** UUID de l\'utilisateur auth');s=s[:a];p.write_text(s)
getters='get(Document|Registry|OpenBanking|PublicData|PortfolioImport|Fec|Import)Repository'
for p in (root/'src/app').rglob('*.ts'):
 s=p.read_text();s=re.sub(r'= ('+getters+r'\(\))',r'= await \1',s);s=re.sub(r'await ('+getters+r'\(\))\.',r'await (await \1).',s);p.write_text(s)
for p in (root/'src').rglob('*test.ts*'):
 s=p.read_text();m=re.search(r'ownerId:\s*\(\)\s*=>\s*([^,\n}]+)',s)
 if m:
  actor=m[1].strip();s=re.sub(r'create(Supabase|Import|Fec)Repository\(\)',lambda x:f'create{x[1]}Repository({actor})',s)
  if re.search(getters+r'\(',s):
   s=f'import {{ requireActor }} from "@/lib/auth";\n'+s
   s+='\nvi.mock("@/lib/auth", () => ({ requireActor: vi.fn() }));\n'
   # The actor is resolved anew, so tests can switch it independently.
   s+=f'\nvi.mocked(requireActor).mockResolvedValue({{userId: {actor}}});\n'
   s=re.sub(r'await ('+getters+r'\(\))\.',r'await (await \1).',s)
 p.write_text(s)
