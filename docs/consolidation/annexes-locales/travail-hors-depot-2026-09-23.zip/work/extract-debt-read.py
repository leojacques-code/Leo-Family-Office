from pathlib import Path
p=Path('src/lib/data/supabase-repository.ts');s=p.read_text()
helpers=[]
def extract(start,end,name,args,ret):
 global s
 a=s.index(start,s.index('async function getDashboardState'));b=s.index(end,a)
 block=s[a:b]
 helpers.append(f'function {name}({args}) {{\n'+block+f'  return {ret};\n}}\n')
 names=ret.strip('{} ').split(', ')
 call=('const { '+', '.join(names)+' }' if ret.startswith('{') else 'const '+ret)
 s=s[:a]+'    '+call+f' = {name}('+', '.join(arg.split(':')[0].strip() for arg in args.split(', '))+');\n\n'+s[b:]
extract('    const institutionNames =','    const assetClassNames =','mapAccountFacts','institutionRows: Row[], accountRows: Row[], balanceRows: Row[]','{ accounts, accountBalanceHistory }')
extract('    const latestLiabilityObservations =','    const incomes:','mapDebtFacts','liabilityRows: Row[], liabilityObservationRows: Row[], loanScheduleRows: Row[], earlyRepaymentRows: Row[], loanChargeRows: Row[], rateChangeRows: Row[], paymentChangeRows: Row[], profileRows: Row[]','liabilities')
extract('    const currentScenarioVersions =','    const profileCurrency =','mapScenarioFacts','scenarioRows: Row[], scenarioVersionRows: Row[]','scenarios')
extract('    const currencyRates:','    const netWorthSnapshots:','mapCurrencyFacts','currencyRateRows: Row[]','currencyRates')
i=s.index('export function createSupabaseRepository')
s=s[:i]+'\n'.join(helpers)+'\n'+s[i:]
s=s.replace('import { mapDecisionCases }','import type { DebtReadModel } from "@/lib/presentation/debt/contracts";\nimport { railSourcesFor } from "@/lib/presentation/rail-sources";\nimport { PAGE_REGISTRY } from "@/lib/presentation/registry/pages";\nimport { mapDecisionCases }')
# Preserve legacy caller contract; debt route can execute without global readback.
s=s.replace('  async function mutateState(mutation: Mutation): Promise<DashboardState> {','  async function executeMutation(mutation: Mutation): Promise<void> {')
s=s.replace('    return getDashboardState();\n  }','  }\n\n  async function mutateState(mutation: Mutation): Promise<DashboardState> {\n    await executeMutation(mutation);\n    return getDashboardState();\n  }',1)
i=s.index('  async function getDashboardState')
s=s[:i]+'''  async function getDebtReadModel(): Promise<DebtReadModel> {
    const now = new Date();
    // Ordre total et lecture de toutes les pages : aucune troncature silencieuse d'échéancier.
    const tables = ["institutions", "financial_accounts", "account_balances", "liabilities",
      "liability_balance_observations", "loan_schedules", "loan_early_repayments",
      "loan_charges", "loan_rate_changes", "loan_payment_changes", "scenarios",
      "scenario_versions", "currency_rates", "profiles"] as const;
    const results = await Promise.all(tables.map((table) => fetchAllPages(table, "id")));
    const rows = Object.fromEntries(results.map((result, index) => [
      tables[index]!, unwrap(result, `lecture #${index}`) as Row[],
    ])) as Record<(typeof tables)[number], Row[]>;
    // Seule la dernière date de clôture est nécessaire, pas son dossier financier.
    const closeResult = await db.from("monthly_closes").select("close_date")
      .eq("user_id", user).order("close_date", { ascending: false }).limit(1);
    const closeRows = unwrap(closeResult, "lecture #14") as Row[];
    const dates = buildFinancialDateContext({ closeDates: closeRows.map((row) => str(row.close_date)), now });
    const reportingCurrency = str(rows.profiles[0]?.reporting_currency || REPORTING_CURRENCY);
    const { accounts, accountBalanceHistory } = mapAccountFacts(rows.institutions, rows.financial_accounts, rows.account_balances);
    const liabilities = mapDebtFacts(rows.liabilities, rows.liability_balance_observations,
      rows.loan_schedules, rows.loan_early_repayments, rows.loan_charges, rows.loan_rate_changes,
      rows.loan_payment_changes, rows.profiles);
    const scenarios = mapScenarioFacts(rows.scenarios, rows.scenario_versions);
    // L'agrégat de cash ne dépend ni des placements, ni de l'immobilier, ni des entreprises.
    // Ce bilan intermédiaire ne quitte pas le serveur et n'est jamais annoncé comme bilan global.
    const cashQuality = buildCanonicalBalanceSheet({ asOfDate: dates.asOfDate, reportingCurrency,
      accounts, positions: [], liabilities: [], currencyRates: mapCurrencyFacts(rows.currency_rates),
    }).immediateCash;
    return { asOfDate: dates.asOfDate, dates, reportingCurrency, liabilities, scenarios,
      metrics: { bankCash: cashQuality.value }, cashQuality,
      railSources: railSourcesFor(PAGE_REGISTRY.debt, { accounts, accountBalanceHistory, liabilities }),
      readAt: now.toISOString(),
    };
  }

'''+s[i:]
s=s.replace('    getDashboardState,\n    mutateState,','    getDashboardState,\n    getDebtReadModel,\n    executeMutation,\n    mutateState,')
p.write_text(s)
p=Path('src/lib/presentation/rail-sources.ts');s=p.read_text().replace('state: DashboardState','state: Partial<DashboardState>');p.write_text(s)
p=Path('src/lib/data/repository.ts');s=p.read_text().replace('import type { DashboardState','import type { DebtReadModel } from "@/lib/presentation/debt/contracts";\nimport type { DashboardState').replace('  getDashboardState(): Promise<DashboardState>;','  getDashboardState(): Promise<DashboardState>;\n  getDebtReadModel(): Promise<DebtReadModel>;\n  executeMutation(mutation: Mutation): Promise<void>;');p.write_text(s)
