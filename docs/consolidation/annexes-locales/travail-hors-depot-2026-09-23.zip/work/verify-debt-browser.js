(async()=>{
 if(location.origin!=='http://127.0.0.1:3107')throw Error('Local recipe only');
 const start=performance.now();const r=await fetch('/api/debt',{cache:'no-store'});const body=await r.text();const m=JSON.parse(body);
 return {status:r.status,milliseconds:performance.now()-start,bytes:new TextEncoder().encode(body).length,keys:Object.keys(m),debt:m.liabilities?.find(x=>x.name==='Dette recette B09')?.currentBalance,cash:m.metrics?.bankCash};
})()
