const {Client}=require('./Leo-Family-Office/node_modules/pg');
(async()=>{
 const c=new Client({connectionString:'postgres://postgres@127.0.0.1:55439/lfo_recipe'});await c.connect();
 const goals=await c.query("select g.name,g.current_version,v.payload->>'purpose' as purpose,v.payload#>>'{target,metric}' as metric,v.payload#>>'{target,value}' as target from goals g join goal_versions v on g.id=v.goal_id and g.current_version=v.version");
 console.log(JSON.stringify({step:'after_browser_create_and_reload',goals:goals.rows}));
 const account=await c.query("select id,institution_id from financial_accounts where name='Liquidités test B04'");
 if(!account.rows.length)throw Error('Compte de recette manquant');
 const extra=await c.query("insert into financial_accounts(user_id,institution_id,name,account_type,currency,liquidity,data_kind,confidence) values ('00000000-0000-4000-8000-000000000001',$1,'Actif illiquide recette B04','OTHER','EUR','ILLIQUID','ACTUAL','HIGH') returning id",[account.rows[0].institution_id]);
 await c.query("insert into account_balances(user_id,account_id,balance,balance_date,data_kind,confidence) values ('00000000-0000-4000-8000-000000000001',$1,8720872.41,current_date,'ACTUAL','HIGH')",[extra.rows[0].id]);
 console.log(JSON.stringify({step:'illiquid_fixture_added',value:8720872.41}));
 await c.end();
})().catch(e=>{console.error(e.message);process.exit(1)});
