const {Client}=require('./Leo-Family-Office/node_modules/pg');
const db=new Client({connectionString:'postgres://postgres@127.0.0.1:55439/lfo_decision_currency_20260923'});
const owner='00000000-0000-4000-8000-000000000001',date='2026-09-23',now=date+'T00:00:00Z';
(async()=>{await db.connect();
if(process.argv[2]==='read') {
console.log(JSON.stringify((await db.query(`select id,result_snapshot->>'reportingCurrency' as currency,result_snapshot->'run'->>'id' as snapshot_run_id,completeness from public.decision_runs order by created_at`)).rows,null,2));
} else {
await db.query(`insert into public.profiles(user_id,display_name,reporting_currency,first_intent) values($1,'Recette devises Décisions','USD','PROJECT') on conflict(user_id) do update set display_name=excluded.display_name,reporting_currency=excluded.reporting_currency,first_intent=excluded.first_intent`,[owner]);
await db.query('select public.lfo_add_account($1,$2,$3,$4,$5,$6,$7)',[owner,'Banque fictive','Compte recette USD','BANK',1200,'USD',date]);
for (let i=1;i<=2;i++) {
const definition={schemaVersion:2,methodologyVersion:'SCENARIOS_V2_EVENT_MONTHLY_1',scenarioId:'00000000-0000-4000-8000-00000000000'+i,version:1,asOfDate:date,horizonMonths:12,lifecycleStatus:'DRAFT',overrides:[],assumptions:[],market:{annualReturn:0,annualVolatility:0,annualInflation:0,stressProbability:0,shockYear:null,shockMagnitude:null,randomVariables:['PORTFOLIO_RETURN']},capitalAllocation:{investmentAllocationRate:0,source:'EXPLICIT'},createdAt:now,legacyCompatibility:null};
await db.query('select public.lfo_create_scenario_v2($1,$2,$3,$4,$5,$6)',[owner,'Recette USD '+i,'Fixture locale jetable','#39747a',definition,now]);
}
console.log('Profil USD, compte USD et deux scénarios de recette créés');
}
await db.end();})().catch(async e=>{console.error(e.message);await db.end();process.exitCode=1});
