from pathlib import Path
p=Path('src/lib/data/supabase-repository.ts');s=p.read_text();a=s.index('  async function getDebtReadModel');b=s.index('  async function getDashboardState',a)
s=s[:a]+'''  async function getDebtReadModel(): Promise<DebtReadModel> {
    const now = new Date();
    const today = operationalToday(now);
    const tables = ["liabilities", "liability_balance_observations", "loan_schedules",
      "loan_early_repayments", "loan_charges", "loan_rate_changes", "loan_payment_changes",
      "scenarios", "scenario_versions", "currency_rates", "profiles"] as const;
    const [results, cashResult, closeResult, transactionResult] = await Promise.all([
      Promise.all(tables.map((table) => table === "profiles"
        ? db.from("profiles").select("reporting_currency").eq("user_id", user).limit(1)
        : fetchAllPages(table, "id"))),
      readAllPages<Row, PostgrestError>("comptes de cash", async (from, to) => {
        const result = await db.from("financial_accounts").select("*").eq("user_id", user)
          .eq("status", "ACTIVE").eq("liquidity", "IMMEDIATE")
          .order("id", { ascending: true }).range(from, to);
        return { data: result.data as Row[] | null, error: result.error };
      }),
      db.from("monthly_closes").select("close_date").eq("user_id", user)
        .lte("close_date", today).order("close_date", { ascending: false }).limit(1),
      // Le rail déclare BANK_TRANSACTIONS : présence/date suffisent, pas le ledger entier.
      db.from("transactions").select("transaction_date").eq("user_id", user)
        .order("transaction_date", { ascending: false }).limit(1),
    ]);
    const rows = Object.fromEntries(results.map((result, index) => [
      tables[index]!, unwrap(result, `lecture #${index}`) as Row[],
    ])) as Record<(typeof tables)[number], Row[]>;
    const cashRows = unwrap(cashResult, "lecture #11") as Row[];
    const closeRows = unwrap(closeResult, "lecture #12") as Row[];
    const transactionRows = unwrap(transactionResult, "lecture #13") as Row[];
    // Un placement sans valorisation n'est pas une dépendance du cash immédiat.
    // Lire aussi ses historiques réintroduirait cette dépendance (et son coût) par le mapping.
    const balanceResult = cashRows.length === 0 ? { data: [], error: null }
      : await readAllPages<Row, PostgrestError>("observations du cash", async (from, to) => {
        const result = await db.from("account_balances").select("*").eq("user_id", user)
          .in("account_id", cashRows.map((row) => str(row.id)))
          .order("balance_date", { ascending: true }).order("id", { ascending: true }).range(from, to);
        return { data: result.data as Row[] | null, error: result.error };
      });
    const balanceRows = unwrap(balanceResult, "lecture #14") as Row[];
    const dates = buildFinancialDateContext({ closeDates: closeRows.map((row) => str(row.close_date)), now });
    const reportingCurrency = str(rows.profiles[0]?.reporting_currency || REPORTING_CURRENCY);
    const { accounts } = mapAccountFacts([], cashRows, balanceRows);
    const liabilities = mapDebtFacts(rows.liabilities, rows.liability_balance_observations,
      rows.loan_schedules, rows.loan_early_repayments, rows.loan_charges, rows.loan_rate_changes,
      rows.loan_payment_changes, rows.profiles);
    const scenarios = mapScenarioFacts(rows.scenarios, rows.scenario_versions);
    // Seul immediateCash est conservé. Ce bilan intermédiaire n'est pas un bilan global.
    const cashQuality = buildCanonicalBalanceSheet({ asOfDate: dates.asOfDate, reportingCurrency,
      accounts, positions: [], liabilities: [], currencyRates: mapCurrencyFacts(rows.currency_rates),
    }).immediateCash;
    return { asOfDate: dates.asOfDate, dates, reportingCurrency, liabilities, scenarios,
      metrics: { bankCash: cashQuality.value }, cashQuality, cashObservationPresent: accounts.length > 0,
      railSources: railSourcesFor(PAGE_REGISTRY.debt, { liabilities }, {
        BANK_TRANSACTIONS: { count: transactionRows.length,
          latestDate: transactionRows[0] ? str(transactionRows[0].transaction_date) : null },
      }), readAt: now.toISOString(),
    };
  }

'''+s[b:];p.write_text(s)
p=Path('src/lib/presentation/rail-sources.ts');s=p.read_text().replace('  state: Partial<DashboardState>,\n): DerivedRailSource[]', '  state: Partial<DashboardState>,\n  evidenceSummaries: Partial<Record<SourceEvidence, { count: number; latestDate: string | null }>> = {},\n): DerivedRailSource[]').replace('const { count, latestDate } = readEvidence(declaration.evidence, state);','const { count, latestDate } = evidenceSummaries[declaration.evidence] ?? readEvidence(declaration.evidence, state);');p.write_text(s)
