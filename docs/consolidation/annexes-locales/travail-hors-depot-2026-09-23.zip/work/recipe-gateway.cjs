// Local-only gateway to native PostgREST; no remote destination or business mock.
const http=require('http'),fs=require('fs'),path=require('path');
const marker=path.join(__dirname,'inject-jwt-error');
http.createServer((req,res)=>{
 const table=(req.url.match(/^\/rest\/v1\/([a-z_]+)/)||[])[1];
 if(table)fs.appendFileSync(path.join(__dirname,'recipe-reads.log'),JSON.stringify({at:new Date().toISOString(),method:req.method,table})+'\n');
 const domainMarker=path.join(__dirname,'inject-domain-error');
 if(req.method==='GET'&&table&&fs.existsSync(domainMarker)&&table===fs.readFileSync(domainMarker,'utf8').trim()){
  res.writeHead(503,{'content-type':'application/json'});res.end(JSON.stringify({code:'TEST',message:'Local recipe read failure',details:null,hint:null}));return;
 }

 if(req.method==='GET' && req.url.startsWith('/rest/v1/profiles') && fs.existsSync(marker)){
  res.writeHead(401,{'content-type':'application/json'});
  res.end(JSON.stringify({code:'PGRST301',message:'JWT issued at future',details:null,hint:null}));return;
 }
 const upstream=http.request({host:'127.0.0.1',port:55440,path:req.url.replace(/^\/rest\/v1/,''),method:req.method,headers:req.headers},r=>{res.writeHead(r.statusCode,r.headers);r.pipe(res);});
 upstream.on('error',()=>{res.writeHead(503);res.end('Local PostgREST unavailable');}); req.pipe(upstream);
}).listen(55441,'127.0.0.1');
