const {Client}=require('./Leo-Family-Office/node_modules/pg');
const fs=require('fs');
const db=new Client({connectionString:'postgres://postgres@127.0.0.1:55439/lfo_auth_gate'});
const owner='00000000-0000-4000-8000-000000000001';
(async()=>{await db.connect();
if(process.argv[2]==='clean') {
 const {id}=JSON.parse(fs.readFileSync(__dirname+'/debt-currency-fixture.json'));
 await db.query('delete from public.liabilities where id=$1 and user_id=$2 and source=$3',[id,owner,'Fixture devise 2026-09-22']);
 console.log(JSON.stringify((await db.query('select count(*)::int as liabilities from public.liabilities where user_id=$1',[owner])).rows));
} else {
 const count=await db.query('select count(*)::int as n from public.liabilities where user_id=$1',[owner]);
 if(count.rows[0].n!==0)throw Error('Refuse: la recette contient déjà une dette');
 await db.query('begin');
 const {rows:[{id}]}=await db.query(`insert into public.liabilities(user_id,lender,name,principal,current_balance,annual_rate,monthly_payment,payment_count,first_payment_date,maturity_date,data_kind,confidence,source,currency,monthly_insurance) values($1,'Banque de recette','Prêt fictif USD',1200,1200,0.02,101,12,'2026-10-01','2027-09-01','ACTUAL','HIGH','Fixture devise 2026-09-22','USD',1) returning id`,[owner]);
 await db.query(`insert into public.liability_balance_observations(user_id,liability_id,observed_at,balance,data_kind,confidence,source) values($1,$2,'2026-09-22',1200,'ACTUAL','HIGH','Fixture devise 2026-09-22')`,[owner,id]);
 await db.query('commit');fs.writeFileSync(__dirname+'/debt-currency-fixture.json',JSON.stringify({id}));console.log('Fixture USD locale créée');
}await db.end();})().catch(async e=>{console.error(e.message);await db.end();process.exitCode=1});
