(async()=>{
 if(location.origin!=='http://127.0.0.1:3107') throw Error('Local recipe only');
 const current=await (await fetch('/api/debt')).json();
 if(current.liabilities.some(x=>x.name==='Dette recette B09'))return {alreadyPresent:true};
 const contract={liabilityId:null,name:'Dette recette B09',lender:'Banque fictive',principal:12000,initialBalance:12000,balanceDate:'2026-09-13',annualRate:0,paymentAmount:1000,paymentCount:12,firstPaymentDate:'2026-10-13',maturityDate:'2027-09-13',amortisationProfile:'AMORTIZING',balloonAmount:null,paymentFrequency:'MONTHLY',interestConvention:'PROPORTIONAL',rateType:'FIXED',insuranceAmount:0,recurringFees:0,paymentIncludesInsurance:false,deferral:null,facilityId:null,notes:'Fixture de recette locale B09',rateSchedule:[],paymentSchedule:[],earlyRepayments:[],charges:[],providedSchedule:[]};
 const response=await fetch('/api/debt',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'save_debt_contract',contract})});
 return {status:response.status,body:await response.json()};
})()
